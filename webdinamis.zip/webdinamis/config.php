<?php
session_start();
$conn = mysqli_connect("localhost:3307", "root", "", "quiz");
?>